const API = "http://localhost:5000/api";

window.onload = () => {
  fetch(API + "/categories")
    .then(r => r.json())
    .then(d => {
      const div = document.getElementById("categories");
      d.categories.forEach(c => {
        const b = document.createElement("button");
        b.textContent = c.strCategory;
        b.onclick = () => loadCategory(c.strCategory);
        div.appendChild(b);
      });
    });
};

function searchMeals(){
  const q=document.getElementById("search").value;
  fetch(API+"/search?q="+q)
    .then(r=>r.json())
    .then(d=>renderMeals(d.meals));
}

function loadCategory(cat){
  fetch(API+"/category/"+cat)
    .then(r=>r.json())
    .then(d=>renderMeals(d.meals));
}

function randomMeal(){
  fetch(API+"/random")
    .then(r=>r.json())
    .then(d=>showModal(d.meals[0]));
}

function renderMeals(meals){
  const div=document.getElementById("results");
  div.innerHTML="";
  meals?.forEach(m=>{
    const img=document.createElement("img");
    img.src=m.strMealThumb;
    img.onclick=()=>loadMeal(m.idMeal);
    div.appendChild(img);
  });
}

function loadMeal(id){
  fetch(API+"/meal/"+id)
    .then(r=>r.json())
    .then(d=>showModal(d.meals[0]));
}

function showModal(meal){
  const modal=document.getElementById("mealModal");
  const body=document.getElementById("modal-body");

  body.innerHTML=`
    <h2>${meal.strMeal}</h2>
    <img class="modal-img" src="${meal.strMealThumb}" />
    <h3>Instructions</h3>
    <p>${meal.strInstructions}</p>
    <h3>Ingredients</h3>
    <ul>${getIngredients(meal).map(i=>`<li>${i}</li>`).join("")}</ul>
  `;

  modal.classList.remove("hidden");
}

function closeModal(){
  document.getElementById("mealModal").classList.add("hidden");
}

function getIngredients(meal){
  let list=[];
  for(let i=1;i<=20;i++){
    const ing=meal[`strIngredient${i}`];
    const m=meal[`strMeasure${i}`];
    if(ing) list.push(`${ing} - ${m}`);
  }
  return list;
}
